# zoomGroupStats 0.1.0
* First full release of package
* Packaged set of functions