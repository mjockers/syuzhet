library(testthat)
library(zoomGroupStats)

test_check("zoomGroupStats")
