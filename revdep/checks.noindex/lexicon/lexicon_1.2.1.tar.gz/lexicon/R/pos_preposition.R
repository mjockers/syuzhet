#' Preposition Words
#'
#' A dataset containing a vector of common prepositions.
#'
#' @docType data
#' @keywords datasets
#' @name pos_preposition
#' @usage data(pos_preposition)
#' @format A character vector with 162 elements
NULL
