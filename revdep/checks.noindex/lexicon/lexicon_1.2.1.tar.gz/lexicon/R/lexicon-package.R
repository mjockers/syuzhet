#' Lexicons for Text Analysis
#'
#' A collection of lexical hash tables, dictionaries, and word lists.
#' @docType package
#' @name lexicon
#' @aliases lexicon package-lexicon
NULL



